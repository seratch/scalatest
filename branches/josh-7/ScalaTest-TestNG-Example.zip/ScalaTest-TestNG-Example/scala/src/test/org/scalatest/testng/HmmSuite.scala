package org.scalatest.testng;

import org.scalatest.fun.FunSuite

class HmmSuite extends FunSuite{
  
  test("why?"){
    println("i dont know")
  }

}
