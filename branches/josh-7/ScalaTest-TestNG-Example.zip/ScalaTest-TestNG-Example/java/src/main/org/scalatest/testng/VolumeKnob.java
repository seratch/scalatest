package org.scalatest.testng;

public interface VolumeKnob {

	public abstract int currentVolume();
	
	public abstract int maxVolume();

	public abstract void turnUp();
	
	public abstract void turnDown();
}